"""Modules de modélisation et d’évaluation coEnergy."""
